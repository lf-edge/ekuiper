# TDengine examples

| No.  |        Name        | Describe                                                     |
| :--: | :----------------: | ------------------------------------------------------------ |
|  1   |      JDBCDemo      | Example codes for JDBC-JNI, JDBC-RESTful, Subscribe          |
|  2   |  connectionPools   | Example codes for HikariCP, Druid, dbcp, c3p0 connection pools |
|  3   | SpringJdbcTemplate | Example codes for spring jdbcTemplate                        |
|  4   |  mybatisplus-demo  | Example codes for mybatis                                    |
|  5   |   springbootdemo   | Example codes for springboot                                 |
|  6   |      taosdemo      | This is an internal tool for testing Our JDBC-JNI, JDBC-RESTful, RESTful interfaces |


more detail: https://www.taosdata.com/cn//documentation20/connector-java/