from concurrent import futures
import logging

import grpc
import sample_pb2
import sample_pb2_grpc
from funcs.label import labelImage


class Sampler(sample_pb2_grpc.AlgorithmsServicer):

    def label(self, request, context):
        f = labelImage(request.base64_img)
        return sample_pb2.LabelReply(results=f)




def serve():
    port = '50051'
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    sample_pb2_grpc.add_AlgorithmsServicer_to_server(Sampler(), server)
    server.add_insecure_port('[::]:' + port)
    server.start()
    print("Server started, listening on " + port)
    server.wait_for_termination()


if __name__ == '__main__':
    logging.basicConfig()
    serve()
