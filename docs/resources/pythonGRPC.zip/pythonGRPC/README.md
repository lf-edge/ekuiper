## Build proto to python code

```shell 
python -m grpc_tools.protoc -I ./ --python_out=./ --grpc_python_out=. ./hello.proto
```

## Build Docker

```shell
 docker build  -t test:1.1.1 -f deploy/Dockerfile-slim-python .
```

## Run Docker

```shell 
docker run -d  -p 50051:50051 --name rpc-test test:1.1.1
```

## Ekuiper extension service

* upload zip file in ekuiper_package to ekuiper
* register file with name `sample`
* call service in ekuiper `select label(name) from demo`, name should be base64 encoded string