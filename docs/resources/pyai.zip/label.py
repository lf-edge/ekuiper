import argparse
import base64
import io
import logging
import time
from typing import List, Any

import numpy as np
from PIL import Image
import tflite_runtime.interpreter as tf

from ekuiper import Function, Context

cwd = 'plugins/portable/pyai/'

def load_labels(filename):
    with open(filename, 'r') as f:
        return [line.strip() for line in f.readlines()]


def label(file_bytes):
    logging.info('labeling image')

    interpreter = tf.Interpreter(
        model_path= cwd + 'mobilenet_v1_1.0_224.tflite')
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # check the type of the input tensor
    floating_model = input_details[0]['dtype'] == np.float32
    logging.info('model loaded')

    encoded = base64.decodebytes(file_bytes.encode("ascii"))
    # NxHxWxC, H:1, W:2
    height = input_details[0]['shape'][1]
    width = input_details[0]['shape'][2]
    img = Image.open(io.BytesIO(encoded)).resize((width, height))
    logging.info('image loaded')

    # add N dim
    input_data = np.expand_dims(img, axis=0)

    if floating_model:
        input_data = (np.float32(input_data) - 127.5) / 127.5

    interpreter.set_tensor(input_details[0]['index'], input_data)

    start_time = time.time()
    interpreter.invoke()
    stop_time = time.time()

    output_data = interpreter.get_tensor(output_details[0]['index'])
    results = np.squeeze(output_data)
    logging.info('result loaded')

    top_k = results.argsort()[-5:][::-1]
    labels = load_labels(cwd + 'labels.txt')
    ret = []
    for i in top_k:
        if floating_model:
            print('{:08.6f}: {}'.format(float(results[i]), labels[i]))
            ret.append({"confidence": float(results[i]), "label": labels[i]})
        else:
            print('{:08.6f}: {}'.format(float(results[i] / 255.0), labels[i]))
            ret.append({"confidence": float(results[i] / 255.0), "label": labels[i]})

    print('time: {:.3f}ms'.format((stop_time - start_time) * 1000))
    logging.info('return counted')
    return ret

class LabelImageFunc(Function):

    def __init__(self):
        pass

    def validate(self, args: List[Any]):
        if len(args) != 1:
            return "invalid arg length"
        return ""

    def exec(self, args: List[Any], ctx: Context):
        logging.debug("executing label")
        return label(args[0])

    def is_aggregate(self):
        return False


labelIns = LabelImageFunc()
