from ekuiper import PluginConfig
from ekuiper.runtime import plugin
from inference import inferenceIns

if __name__ == '__main__':
    c = PluginConfig("defect", {}, {},
                     {"inference": lambda: inferenceIns})
    plugin.start(c)
