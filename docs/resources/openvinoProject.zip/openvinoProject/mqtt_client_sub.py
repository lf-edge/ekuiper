# python3.6
import base64
import json
import random

import cv2
import numpy as np
from paho.mqtt import client as mqtt_client

broker = '122.9.166.75'
port = 1883
topic = "demo_out"
# Generate a Client ID with the subscribe prefix.
client_id = f'subscribe-{random.randint(0, 100)}'


# username = 'emqx'
# password = 'public'


def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def base64_to_image(base64_code):
    # base64解码
    img_data = base64.b64decode(base64_code)
    # 转换为np数组
    img_array = np.frombuffer(img_data, np.uint8)
    # 转换成opencv可用格式
    img = cv2.imdecode(img_array, cv2.COLOR_RGB2BGR)

    return img


def on_message(client, userdata, msg):
    print(f"Received msg from `{msg.topic}` topic")

    data_receive = msg.payload.decode('utf-8')

    unpacked_json = json.loads(data_receive)

    image_base64 = unpacked_json['inference']['base64']
    # print("主题:" + msg.topic + " 消息:" + image_base64)

    vis_im = base64_to_image(image_base64)

    cv2.imwrite("./visualized_result.jpg", vis_im)


def subscribe(client: mqtt_client):
    client.subscribe(topic)
    client.on_message = on_message


def run():
    client = connect_mqtt()
    subscribe(client)
    client.loop_forever()


if __name__ == '__main__':
    run()
